=== Business Purpose ===
Contributors: Iamds
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Business Purpose WordPress Theme ==

Business Purpose WordPress Theme is child theme of Radon WordPress Theme, Copyright 2018 Webdzier
Business Purpose WordPress Theme is distributed under the terms of the GNU GPL

Business Purpose WordPress Theme, Copyright 2018 Webdzier
Business Purpose is distributed under the terms of the GNU GPL


== About Author - Contact Details ==

email       :   coder@codeozone.com


== Installation ==

1. Go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.6 =
* Removed Subject tags from style.css file.
* Image licensed added in readme.txt file.
* Screenshot image URL added in readme.txt file.

= 1.5 =
* Initial upload

**Images**

## Images ##

License: All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/


*screenshot*
	( unsplash.com )
	https://unsplash.com/photos/uLDmm65P5ZY


For any help you can mail us at webdzier[at]gmail.com